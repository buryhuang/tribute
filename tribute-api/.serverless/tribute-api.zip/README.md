# Tribute API

## Run from local
```
pipenv shell
pipenv install
flask run
```
The server should be up and running on http://localhost:5000

## Deploy to cloud
```
npm install -g serverless
serverless deploy
```
