import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='buryhuang',
    application_name='tribute-api',
    app_uid='bGfZLNLzw3JfXM0TY3',
    org_uid='gdblyTPqhhKKN61pvb',
    deployment_uid='3a569c8b-d3cd-49f0-ac2b-91f00b276d6b',
    service_name='tribute-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.4.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'tribute-api-dev-api', 'timeout': 60}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
